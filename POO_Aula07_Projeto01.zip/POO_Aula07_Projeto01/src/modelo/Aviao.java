package modelo;

public class Aviao extends Veiculo {

    public Aviao() {
        super();
    }
    
    @Override
    public void acelerar() {
        //aumentar a velocidade em 10 unidade
        setVelocidade(getVelocidade() + 10) ;
    }
    
}
