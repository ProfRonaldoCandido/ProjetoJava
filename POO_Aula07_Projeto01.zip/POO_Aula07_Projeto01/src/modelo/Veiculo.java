package modelo;

public abstract class Veiculo {
    //atributos
    private int velocidade ;
    private boolean status ;

    public Veiculo() {
    }

    public Veiculo(int velocidade, boolean status) {
        this.velocidade = velocidade;
        this.status = status;
    }

    public int getVelocidade() {
        return velocidade;
    }

    public void setVelocidade(int velocidade) {
        this.velocidade = velocidade;
    }
    //métodos booleanos usam o verbo is....
    public boolean isStatus() {
        return status;
    }

    public void setStatus(boolean status) {
        this.status = status;
    }
    //método ligar()
    public void ligar() {
        this.status = true ;
    }
    //método desligar
    public void desligar() {
        this.status = false ;
    }
    //método mostrar status
    public void mostrarStatus() {
//        if (status==true) {
//            System.out.println("Está ligado !") ;
//        }
//        else {
//            System.out.println("Está desligado !") ;
//        }
        //simplificando o método (operador ternário ?)
        System.out.println((status?"Está ligado!":"Está desligado"));
    } //fim do método
    //método abstrato
    public abstract void acelerar();
    
}//fim da classe
