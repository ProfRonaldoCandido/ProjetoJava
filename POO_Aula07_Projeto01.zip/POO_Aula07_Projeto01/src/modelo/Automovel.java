package modelo;

public final class Automovel extends Veiculo {

    public Automovel() {
        super() ;
    }

    //método polimórfico sobreescrito
    @Override
    public void acelerar() {
        //aumentar a velocidade em 1 unidade
        setVelocidade(getVelocidade() + 1) ;
    }
}
