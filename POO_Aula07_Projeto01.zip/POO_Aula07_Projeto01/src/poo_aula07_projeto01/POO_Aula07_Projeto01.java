package poo_aula07_projeto01;
import modelo.Veiculo ;

import modelo.Automovel;
import modelo.Aviao;

public class POO_Aula07_Projeto01 {

    public static void main(String[] args) {
        //mensagem de início
        System.out.println("Cadastro de Veículos");

        //tentar criar um veículo
        //Veiculo v1 = new Veiculo() ;
        //criar um automóvel
        Automovel a1 = new Automovel();
        a1.ligar();
        a1.acelerar();
        System.out.println("Velocidade do automóvel: " + a1.getVelocidade());
        a1.acelerar();
        System.out.println("Nova velocidade: " + a1.getVelocidade());
        //a1.desligar();
        a1.mostrarStatus();
        
        //objeto Avião
        Aviao av = new Aviao() ;
        av.ligar();
        av.acelerar();
        System.out.println("Velocidade do avião: " + av.getVelocidade());
        av.acelerar();
        System.out.println("Nova velocidade: " + av.getVelocidade());
        av.mostrarStatus();
        av.desligar();
        av.mostrarStatus();
        
        Veiculo v = new Automovel() ;
        v.acelerar();
        v.mostrarStatus();
    }//fim do main
} //fim da classe





