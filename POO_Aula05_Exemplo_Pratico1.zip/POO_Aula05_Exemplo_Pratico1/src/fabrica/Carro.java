package fabrica;

public class Carro {

    //atributos
    private String modelo;
    private Motor motor;

    public Carro() {
    }

    public Carro(String modelo, Motor motor) {
        this.modelo = modelo;
        this.motor = motor;
    }

    public String getModelo() {
        return modelo;
    }

    public void setModelo(String modelo) {
        this.modelo = modelo;
    }

    public Motor getMotor() {
        return motor;
    }

    public void setMotor(Motor motor) {
        this.motor = motor;
    }

    //método da velocidade máxima
    public float obterVelocidadeMaxima() {
        float velocidade = 0;
        float c = getMotor().getCilindrada();
        //verificar a cilindrada
        if (c <= 1) {
            velocidade = 140;
        } else if (c <= 1.6) {
            velocidade = 180;
        } else if (c <= 2) {
            velocidade = 220;
        } else {
            velocidade = 260;
        }
        //retornar o valor da velocidade
        return velocidade;
    }
} //fim da classe
