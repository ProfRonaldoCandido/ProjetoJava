package fabrica;

public class Motor {
    //atributo
    private float cilindrada ;

    public Motor() {
    }

    public Motor(float cilindrada) {
        this.cilindrada = cilindrada;
    }

    public float getCilindrada() {
        return cilindrada;
    }

    public void setCilindrada(float cilindrada) {
        this.cilindrada = cilindrada;
    }
}
