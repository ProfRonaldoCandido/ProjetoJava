package poo_aula05_exemplo_pratico1;

import fabrica.Carro;
import fabrica.Motor;
import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

public class POO_Aula05_Exemplo_Pratico1 {

    public static void main(String[] args) {
        //exemplo Prático da Aula05
        List<Motor> listaMotores = new ArrayList<Motor>() ;
        List<Carro> listaCarros = new ArrayList<Carro>() ;
        System.out.println("Aula 05 - Exemplo prático") ;
        System.out.println("-------------------------") ;
        //entrada de dados
        Scanner sc = new Scanner(System.in) ;
        System.out.print("Informe o valor da cilindrada: ");
        float cil = sc.nextFloat() ;
        System.out.print("Informe o modelo do carro: ");
        String modelo = sc.next() ;
        //processamento de dados
        Motor m1 = new Motor() ;
        m1.setCilindrada(cil);
        listaMotores.add(m1) ;
        //Motor m1 = new Motor(cil) ;
        Carro c1 = new Carro(modelo,m1) ; //agregação
        listaCarros.add(c1) ;
        //saída de dados
        System.out.println("Dados do carro: ");
        System.out.println("Modelo: " + c1.getModelo());
        System.out.println("Cilindrada: " + c1.getMotor().getCilindrada());
        System.out.println("Velocidade máxima: " 
                + c1.obterVelocidadeMaxima() + " Km/h");
    }
    
}
