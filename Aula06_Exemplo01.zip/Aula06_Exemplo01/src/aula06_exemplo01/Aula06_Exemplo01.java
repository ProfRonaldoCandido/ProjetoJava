package aula06_exemplo01;

import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;
import modelo.Produto;

public class Aula06_Exemplo01 {

    public static void main(String[] args) {
        //Criar tipo de lista
        List produtos = new ArrayList<>();
        System.out.println("##### Cadastro de produtos #####\n");
        try (Scanner entrada = new Scanner(System.in)) {
            String continuar = "s";
            //repetir enquanto apertar "s"
            while ("s".equalsIgnoreCase(continuar)) {
                System.out.print("SKU: ");
                String sku = entrada.nextLine();
                System.out.print("Nome: ");
                String nome = entrada.nextLine();
                Produto produto = new Produto(sku, nome);
                //verificar se já contém o produto
                if (produtos.contains(produto)) {
                    System.err.println("Esse produto já foi adicionado. Utilize outro SKU!");
                } else {
                    produtos.add(produto); //adicionar à lista
                    System.out.println("Produto adicionado.");
                }
                System.out.print("Deseja adicionar mais algum produto? (s/n) ");
                continuar = entrada.nextLine();
            }
        } //fim do try
        //percorrer a lista, imprimindo os dados
        produtos.forEach(System.out::println);
        System.out.println("Fim");
    } //fim do main()
} //fim da classe

