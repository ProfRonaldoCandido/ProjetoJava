package aula02_projeto01b;

public class Aula02_Projeto01b {

    public static void main(String[] args) {
        //testando
        System.out.println("Aula 02 - Classes com Herança");
        //entrada de dados
        String n1 = "Ana";
        String e1 = "Rua das Flores, 500";

        //criar o objeto
        Pessoa p = new Pessoa(n1, e1);

        //saída de dados
        //System.out.println(p.imprimir());
        p.setNome("Ana Maria dos Santos");
        System.out.println(p.imprimir());

        //funcionários
        Funcionario f = new Funcionario();
        f.setNome("Alberto");
        f.setEndereco("R.das Esmeraldas, 500");
        f.setMatricula(123);
        f.setSalario(1200.00F);
        System.out.println(f.imprimir()); // imprime tudo?

    }

}
