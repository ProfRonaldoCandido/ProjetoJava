package aula02_projeto01b;

public class Funcionario extends Pessoa{
    //atributos
    private int matricula ;
    private float salario ;
    
    //construtores
    public Funcionario() {
        super() ;
        this.matricula = 0 ;
        this.salario = 0.0F ;
    }

    public Funcionario(int matricula, float salario, String nome, String endereco) {
        super(nome, endereco);
        this.matricula = matricula;
        this.salario = salario;
    }

    public int getMatricula() {
        return matricula;
    }

    public void setMatricula(int matricula) {
        this.matricula = matricula;
    }

    public float getSalario() {
        return salario;
    }

    public void setSalario(float salario) {
        this.salario = salario;
    }
    //imprimir todos os dados
    public String imprimir() {
        return super.imprimir() + "\nMatrícula: " + matricula 
                + "\nSalário: R$ " + salario ;
    }
    
}
