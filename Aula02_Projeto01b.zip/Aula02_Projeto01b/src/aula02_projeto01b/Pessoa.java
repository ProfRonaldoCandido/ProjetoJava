package aula02_projeto01b;

public class Pessoa {
    //atributos
    private String nome,endereco ;
    
    //método construtor padrão
    public Pessoa() {
        //altera o valor NULL para ""
        this.nome = "" ;
        this.endereco = "" ;
    }
    //método construtor sobrecarregado
    public Pessoa(String nome, String endereco) {
        this.nome = nome;
        this.endereco = endereco;
    }
    //métodos set e get

    public String getNome() {
        return nome;
    }

    public void setNome(String nome) {
        this.nome = nome;
    }

    public String getEndereco() {
        return endereco;
    }

    public void setEndereco(String endereco) {
        this.endereco = endereco;
    }
    
    //novos métodos
    public String imprimir() {
        return "Nome: " + this.nome + "\nEndereço: " + endereco ; 
    }
    
    
} //fim da classe
