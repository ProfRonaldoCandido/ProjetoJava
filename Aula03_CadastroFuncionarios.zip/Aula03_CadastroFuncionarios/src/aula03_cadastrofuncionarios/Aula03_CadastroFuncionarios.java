package aula03_cadastrofuncionarios;

import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;
import modelo.Funcionario;

public class Aula03_CadastroFuncionarios {

    //função para cadastrar funcionários
    public static Funcionario cadastrar() {
        System.out.println("Cadastrar dados de funcionário");
        //cria um objeto para entrada pelo teclado
        Scanner teclado = new Scanner(System.in);
        //entrada de dados
        System.out.print("Digite a matrícula: ");
        int mat = teclado.nextInt();
        System.out.print("Digite o nome: ");
        String nome = teclado.next();
        System.out.print("Digite o endereço: ");
        String endereco = teclado.next();
        System.out.print("Digite o salário: ");
        float salario = teclado.nextFloat();
        //guardar os dados no objeto
        Funcionario f = new Funcionario(mat, salario, nome, endereco);
        return f;
    }

    //exibir a lista de funcionários
    public static void exibirLista(List<Funcionario> lista) {
        //percorrer a lista
        for (Funcionario f : lista) {
            System.out.println(f.imprimir());
        }
    }

    //método principal
    public static void main(String[] args) {
        //executar o método de cadastro
        Funcionario func = null;
        //criar lista de funcionários
        List<Funcionario> lista = new ArrayList<Funcionario>();
        for (int i = 0; i < 3; i++) {
            func = cadastrar(); //trará o funcionário
            //adicionar o funcionário
            lista.add(func);
        }
        //exibir a lista
        exibirLista(lista);

    }

}
